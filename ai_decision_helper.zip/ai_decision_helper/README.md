# AI Decision Helper

A small, explainable Python tool for deciding whether a business requirement needs AI,
and if so, which approach is a sensible starting point.

## Concepts behind the categories

- **AI** is the broad field of building systems that perform tasks associated with
  intelligence, such as perception, reasoning or language.
- **Machine Learning (ML)** is a subset of AI in which a system learns patterns from
  examples/data instead of relying only on hand-written rules.
- **Deep Learning** is a subset of ML that uses multi-layer neural networks. It is
  especially useful for complex inputs such as images, audio and video.
- **Generative AI** creates new content such as text, code, images or summaries,
  usually using large foundation models. Retrieval-augmented generation (RAG) can
  connect a language model to approved documents.

The helper follows a **simplest adequate solution** principle. Deterministic work
should normally use ordinary code; dashboards use analytics/BI; predictive tasks use
ML; image perception often uses deep learning; and generated language uses
generative AI.

## Requirements included

The 8 requested cases plus 2 additional examples are stored as Python data:
1. PAN format validation
2. Customer cancellation prediction
3. Support email summarisation
4. Product-photo defect detection
5. GST calculation
6. Weekly product-demand forecast
7. HR policy PDF question answering
8. Invoice sorting by amount
9. Expense-spend dashboard (additional)
10. Suspicious transaction detection (additional)

Each record has yes/no attributes for fixed rules, learning, unstructured input,
generated content, data availability, prediction, visual perception and document
retrieval. The decision function returns a category and reasons.

## Run

Requires Python 3.8+; no third-party packages are needed.

```bash
python decision_helper.py
```

The program prints the classifications and lifecycle map, then creates
`decision_report.csv` in the current directory.

Run the assert-based tests:

```bash
python decision_helper.py --test
```

Expected test output:

```text
All 5 tests passed.
```

## Sample output

```text
AI DECISION HELPER
========================================================================

PAN format validation: No AI (rules/code)
  Why: The task has deterministic rules or a direct calculation. A normal
  program is easier to test, explain and maintain than an AI model.

Customer cancellation prediction: Classical ML
  Why: The task predicts an outcome or future value from historical examples.
  A classical ML/forecasting model can learn patterns from structured data.

Product-photo defect detection: Deep Learning
  Why: The input is an image and the task requires visual pattern recognition.
  Deep-learning vision models can learn defect features from labelled photographs.

HR policy PDF question answering: Generative AI
  Why: The requirement asks for a natural-language answer generated from documents.
  Retrieval can ground the answer in approved policy passages; citations and access
  controls are important.

Wrote decision_report.csv
```

## Lifecycle map

For every AI/analytics-suitable requirement, the script includes five stages:
problem framing, data, model/solution, deployment and monitoring. Each stage has
one concrete task and an accountable role. "No AI" items are intentionally omitted
from the AI lifecycle map and instead receive a simple-code next step in the CSV.

## Important limitations

This is a first-pass decision aid, not an automatic architecture decision. Validate
data quality, privacy, security, legal requirements, cost, latency and human oversight
before implementation. For example, PAN format validation checks syntax only; it
does not verify that a PAN is authentic.
