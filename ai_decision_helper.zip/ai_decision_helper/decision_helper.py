"""
AI Decision Helper
Classifies business requirements by the simplest suitable approach.
Run: python decision_helper.py
Run tests: python decision_helper.py --test
"""

from dataclasses import dataclass
from typing import Dict, List
import csv
import sys


@dataclass
class Requirement:
    name: str
    description: str
    fixed_rules_possible: bool
    needs_learning: bool
    unstructured_input: bool
    needs_generated_content: bool
    data_available: bool
    predictive: bool
    visual_perception: bool = False
    needs_document_retrieval: bool = False
    risk: str = ""


REQUIREMENTS = [
    Requirement(
        "PAN format validation", "Check whether a PAN follows the required character pattern.",
        True, False, False, False, False, False,
        risk="A valid format does not prove that the PAN is genuine or belongs to the claimant."
    ),
    Requirement(
        "Customer cancellation prediction", "Predict which customers are likely to cancel next month.",
        False, True, False, False, True, True,
        risk="Biased or stale data can produce unfair or inaccurate customer scores."
    ),
    Requirement(
        "Support email summarisation", "Create a concise summary of long support emails.",
        False, False, True, True, True, False,
        risk="The summary may omit important details or invent unsupported information."
    ),
    Requirement(
        "Product-photo defect detection", "Identify visible defects in product photographs.",
        False, True, True, False, True, True, visual_perception=True,
        risk="Poor lighting, camera changes and rare defects can reduce detection accuracy."
    ),
    Requirement(
        "GST calculation", "Calculate GST from invoice value and the applicable tax rate.",
        True, False, False, False, False, False,
        risk="Incorrect tax rates or rounding rules can still cause financial errors."
    ),
    Requirement(
        "Weekly product-demand forecast", "Forecast next week's demand using historical sales.",
        False, True, False, False, True, True,
        risk="Promotions, stockouts and seasonality can make historical patterns unreliable."
    ),
    Requirement(
        "HR policy PDF question answering", "Answer employee questions using an HR policy PDF.",
        False, False, True, True, True, False, needs_document_retrieval=True,
        risk="Outdated policy content or weak citations can lead to incorrect HR guidance."
    ),
    Requirement(
        "Invoice sorting by amount", "Sort invoices from highest to lowest amount.",
        True, False, False, False, False, False,
        risk="Incorrectly extracted amounts should be checked before sorting."
    ),
    # Added requirement 1
    Requirement(
        "Expense-spend dashboard", "Show monthly spend by department and highlight trends.",
        False, False, False, False, True, False,
        risk="Incomplete or inconsistently coded transactions can distort the dashboard."
    ),
    # Added requirement 2
    Requirement(
        "Suspicious transaction detection", "Flag transactions that look unusual compared with normal activity.",
        False, True, False, False, True, True,
        risk="False positives can inconvenience customers; fraud patterns also change over time."
    ),
]

LIFECYCLE = {
    "Customer cancellation prediction": [
        ("Problem framing", "Define cancellation, prediction horizon and an actionable intervention.", "Product owner"),
        ("Data", "Build a customer-level dataset with historical behaviour and cancellation labels.", "Data engineer"),
        ("Model", "Train and validate a classification model; check precision, recall and bias.", "Data scientist"),
        ("Deployment", "Expose monthly risk scores to the retention team through a batch job or API.", "ML engineer"),
        ("Monitoring", "Track drift, model quality and retention outcomes; retrain when needed.", "ML engineer"),
    ],
    "Support email summarisation": [
        ("Problem framing", "Agree summary format, target users and acceptable omission/error rate.", "Product owner"),
        ("Data", "Collect approved, redacted examples and define privacy/retention rules.", "Data steward"),
        ("Model", "Evaluate a generative language model against human-written reference summaries.", "AI engineer"),
        ("Deployment", "Add a human-review step in the support-agent workflow.", "Software engineer"),
        ("Monitoring", "Sample summaries for factuality, omissions, latency and cost.", "Support operations lead"),
    ],
    "Product-photo defect detection": [
        ("Problem framing", "Define defect classes, severity and the inspection decision threshold.", "Quality manager"),
        ("Data", "Capture and label representative good/defective images across product types.", "Data engineer"),
        ("Model", "Train and test an image classifier or object-detection model.", "Computer-vision data scientist"),
        ("Deployment", "Integrate image scoring with the inspection station and fallback process.", "ML engineer"),
        ("Monitoring", "Review false rejects/misses and monitor camera and product mix changes.", "Quality analyst"),
    ],
    "Weekly product-demand forecast": [
        ("Problem framing", "Define forecast granularity, horizon and error metric for planning.", "Supply-chain product owner"),
        ("Data", "Prepare clean sales, inventory, price, promotion and calendar history.", "Data engineer"),
        ("Model", "Compare seasonal-naive baselines with forecasting models using time-based validation.", "Data scientist"),
        ("Deployment", "Publish weekly SKU forecasts to the replenishment/planning system.", "ML engineer"),
        ("Monitoring", "Track forecast error, bias and performance by product group.", "Demand planner"),
    ],
    "HR policy PDF question answering": [
        ("Problem framing", "Limit answers to approved HR topics and define escalation cases.", "HR product owner"),
        ("Data", "Extract, chunk, version and permission-check the current policy documents.", "Knowledge engineer"),
        ("Model", "Build retrieval-augmented generation and test answer grounding with citations.", "Generative-AI engineer"),
        ("Deployment", "Deploy an authenticated employee assistant with links to source passages.", "Software engineer"),
        ("Monitoring", "Review unanswered questions, citation quality and policy-version freshness.", "HR knowledge owner"),
    ],
    "Expense-spend dashboard": [
        ("Problem framing", "Agree spend measures, department breakdowns and refresh frequency.", "Finance product owner"),
        ("Data", "Connect and validate the general-ledger and expense data.", "Data engineer"),
        ("Model", "Create governed aggregations, measures and trend calculations.", "BI developer"),
        ("Deployment", "Publish role-based dashboard views to finance and department leads.", "BI developer"),
        ("Monitoring", "Check refresh failures, reconciliation totals and dashboard usage.", "Finance analyst"),
    ],
    "Suspicious transaction detection": [
        ("Problem framing", "Define suspicious outcomes, review capacity and false-alert tolerance.", "Risk product owner"),
        ("Data", "Prepare historical transaction features and verified investigation outcomes.", "Data engineer"),
        ("Model", "Train an anomaly-detection or supervised classification model and compare to rules.", "Data scientist"),
        ("Deployment", "Route risk-ranked alerts to analysts; do not auto-block solely on a score.", "ML engineer"),
        ("Monitoring", "Track alert precision, analyst feedback, drift and emerging fraud patterns.", "Fraud operations lead"),
    ],
}


def classify(req: Requirement) -> Dict[str, str]:
    """Return category and transparent reasons; prefer the simplest adequate solution."""
    if req.fixed_rules_possible and not req.needs_learning and not req.needs_generated_content:
        category = "No AI (rules/code)"
        reasons = [
            "The task has deterministic rules or a direct calculation.",
            "A normal program is easier to test, explain and maintain than an AI model."
        ]
    elif req.needs_generated_content and req.needs_document_retrieval:
        category = "Generative AI"
        reasons = [
            "The requirement asks for a natural-language answer generated from documents.",
            "Retrieval can ground the answer in approved policy passages; citations and access controls are important."
        ]
    elif req.needs_generated_content:
        category = "Generative AI"
        reasons = [
            "The output is newly generated natural-language content.",
            "A language model can summarise or draft content; human review is appropriate for important cases."
        ]
    elif req.visual_perception:
        category = "Deep Learning"
        reasons = [
            "The input is an image and the task requires visual pattern recognition.",
            "Deep-learning vision models can learn defect features from labelled photographs."
        ]
    elif req.needs_learning and req.predictive:
        category = "Classical ML"
        reasons = [
            "The task predicts an outcome or future value from historical examples.",
            "A classical ML/forecasting model can learn patterns from structured data."
        ]
    elif req.needs_learning:
        category = "Classical ML"
        reasons = [
            "The task needs patterns learned from examples rather than only fixed rules.",
            "A trained model is appropriate if representative, labelled data is available."
        ]
    else:
        category = "Analytics/BI"
        reasons = [
            "The task mainly aggregates, compares or visualises existing data.",
            "SQL, metrics and dashboards are more suitable than a predictive model."
        ]

    if req.needs_learning and not req.data_available:
        reasons.append("Important caveat: suitable historical data is not yet confirmed.")
    return {"category": category, "reasons": " ".join(reasons)}


def lifecycle_for(req_name: str) -> List[tuple]:
    return LIFECYCLE.get(req_name, [])


def write_report(path: str = "decision_report.csv") -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f, fieldnames=["requirement", "decision", "reasons", "risks", "first_next_step"]
        )
        writer.writeheader()
        for req in REQUIREMENTS:
            result = classify(req)
            stages = lifecycle_for(req.name)
            if result["category"] == "No AI (rules/code)":
                next_step = "Implement a small deterministic function and add unit tests."
            elif stages:
                next_step = f"{stages[0][1]} (Owner: {stages[0][2]})."
            else:
                next_step = "Confirm the business question, data source and success metric."
            writer.writerow({
                "requirement": req.name,
                "decision": result["category"],
                "reasons": result["reasons"],
                "risks": req.risk,
                "first_next_step": next_step,
            })


def run_tests() -> None:
    by_name = {r.name: r for r in REQUIREMENTS}
    assert classify(by_name["GST calculation"])["category"] == "No AI (rules/code)"
    assert classify(by_name["PAN format validation"])["category"] == "No AI (rules/code)"
    assert classify(by_name["Product-photo defect detection"])["category"] == "Deep Learning"
    assert classify(by_name["HR policy PDF question answering"])["category"] == "Generative AI"
    assert classify(by_name["Expense-spend dashboard"])["category"] == "Analytics/BI"
    print("All 5 tests passed.")


def main() -> None:
    if "--test" in sys.argv:
        run_tests()
        return

    print("AI DECISION HELPER")
    print("=" * 72)
    for req in REQUIREMENTS:
        result = classify(req)
        print(f"\n{req.name}: {result['category']}")
        print(f"  Why: {result['reasons']}")
        if result["category"] != "No AI (rules/code)":
            print("  Lifecycle:")
            for stage, task, role in lifecycle_for(req.name):
                print(f"    - {stage}: {task} [Owner: {role}]")
    write_report()
    print("\nWrote decision_report.csv")


if __name__ == "__main__":
    main()
